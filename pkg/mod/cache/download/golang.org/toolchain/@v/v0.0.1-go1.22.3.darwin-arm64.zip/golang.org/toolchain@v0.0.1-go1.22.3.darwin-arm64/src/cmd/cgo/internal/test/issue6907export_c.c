// Copyright 2017 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

#include <string.h>

#include "_cgo_export.h"

int CheckIssue6907C(_GoString_ s) {
	return CheckIssue6907Go(s);
}
